/**
 * Created with IntelliJ IDEA.
 * User: firsa_as
 * Date: 08.11.13
 * Time: 14:57
 * To change this template use File | Settings | File Templates.
 */
public class Outcast {
    // constructor takes a WordNet object
    public Outcast(WordNet wordnet) {

    }

    // given an array of WordNet nouns, return an outcast
    public String outcast(String[] nouns) {

        return  "ff";
    }

    // for unit testing of this class (such as the one below)
    public static void main(String[] args) {

    }
}
